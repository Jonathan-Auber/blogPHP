<?php
session_start();

if(!isset($_SESSION["id"])){

    header("Location: deconnexion.php");
}


 // 1. connexion a la bdd
 try{

    $pdo = new PDO("mysql:host=localhost;dbname=blog", "root", "");

}catch(PDOException $e){

    echo $e->getMessage();
}

$select = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$select->execute([$_GET["id"]]);
$data = $select->fetch();





?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Bienvenu <?= $_SESSION["username"] ?> </p>
    
    <h1>page <?php echo $data["username"]; ?></h1>
    

    <a href="deconnexion.php">deconnexion</a>

    <?php
        if($_GET["id"] === $_SESSION["id"]){
    ?>

        <a href="">paramettre</a>

    <?php
        }
    ?>
</body>
</html>